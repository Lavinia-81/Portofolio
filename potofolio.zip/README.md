# 🌟 Maria Lavinia Dusca — Interactive CV

Welcome to my digital CV — a handcrafted, responsive, and poetic presentation of my journey as a Front-End Developer and Digital Creator.

This project blends structure with soul: it showcases my skills, projects, and professional growth through a clean interface, subtle animations, and thoughtful design.

---

## 💼 About Me

I am currently employed at **The Very Group** as an Outbound Admin, actively transitioning into Front-End Development. Over the past year, I’ve completed **400+ hours of study**, published original products on **Etsy** and **Gumroad**, and built a constellation of projects on **GitHub** and **Netlify**.

My focus is on:

- ✨ Front-End Development (HTML, CSS, JavaScript, React)
- 🎨 Web Design (UX/UI integration, responsive layouts)
- ⚙️ DevOps Awareness (Docker, Jenkins, AWS, Terraform)

---

## 🛠️ Technologies Used

- HTML5 / CSS3 / JavaScript
- Responsive Design Principles
- Boxicons, EmailJS, ScrollReveal
- GitHub & Netlify for deployment

---

## 📦 Published Products

- **Interactive Weekly Calendar**  
- **Responsive Analog & Digital Clock**  
- **AWS Exam Prep Planner**

Available on [Etsy](https://www.etsy.com/shop/yourshop) and [Gumroad](https://gumroad.com/yourprofile)

---

## 🚀 Projects

Explore more on:

- [GitHub](https://github.com/Lavinia-81)
- [Netlify Portfolio](https://maria-portfolio.netlify.app)

---

## 📬 Contact

Feel free to reach out via email:  
**marialavinia801@yahoo.com**

---

> _“Each line of code is a quiet declaration of growth.”_

Thank you for visiting 🌸