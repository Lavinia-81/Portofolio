let menuIcon = document.querySelector('#menu-icon');
let navbar = document.querySelector('.navbar');

menuIcon.onclick = () => {
  menuIcon.classList.toggle('bx-x');
  navbar.classList.toggle('active');
};

let sections = document.querySelectorAll('section');
let navLinks = document.querySelectorAll('header nav a');

window.onscroll = () => {
  sections.forEach(sec => {
    let top = window.scrollY;
    let offset = sec.offsetTop -150;
    let height = sec.offsetHeight;
    let id = sec.getAttribute('id');

    if(top >= offset && top < offset + height) {
      navLinks.forEach(links => {
        links.classList.remove('active');
        document.querySelector('header nav a[href*=' + id + ']').classList.add('active');
      });
    };
  });

  let header = document.querySelector('header');
  header.classList.toggle('sticky', window.scrollY > 100);


menuIcon.classList.remove('bx-x');
navbar.classList.remove('active');
};
// ScrollReveal({
//   reset: true,
//   distance: '80px',
//   duration: 2000,
//   delay: 200
//  });

ScrollReveal().reveal('.home-content, .heading, .home-img, .services-container, .portfolio-box, .contact form, .home-content h1, .about-img, .home-content p, .about-content', {
  origin: 'bottom',
  distance: '50px',
  duration: 1000,
  delay: 300,
  reset: true
});

 ScrollReveal().reveal('.home-content, .heading', { origin: 'top' });
 ScrollReveal().reveal('.home-img, .services-container, .portfolio-box, .contact form', { origin: 'bottom' });
 ScrollReveal().reveal('.home-content h1, .abount-img', { origin: 'left' });
 ScrollReveal().reveal('.home-content p, .abount-content', { origin: 'right' });




  emailjs.init({
    publicKey: "lb3jaySW3tXfVSF3y"
  });

  document.getElementById("contact-form").addEventListener("submit", function (e) {
    e.preventDefault();

    emailjs.sendForm("service_en3iud9", "template_8rscxee", this)
      .then(() => {
        alert("Message sent successfully!");
        this.reset();
      })
      .catch((error) => {
        console.error("EmailJS Error:", error);
        alert("Message failed to send. Check console for details.");
      });
  });

  const currentYear = new Date().getFullYear();
document.getElementById("copyright-text").innerHTML =
  `Copyright © ${currentYear} by Maria-Lavinia Dusca | All Rights Reserved`;